const fs = require("fs");
const sourceJson = {
    "id": 5958602653954,
    "admin_graphql_api_id": "gid://shopify/Order/5958602653954",
    "app_id": 161501970433,
    "browser_ip": null,
    "buyer_accepts_marketing": false,
    "cancel_reason": null,
    "cancelled_at": null,
    "cart_token": null,
    "checkout_id": null,
    "checkout_token": null,
    "client_details": null,
    "closed_at": null,
    "confirmation_number": "M08VNYY8M",
    "confirmed": true,
    "contact_email": null,
    "created_at": "2024-09-19T23:57:06+05:30",
    "currency": "INR",
    "current_subtotal_price": "224.97",
    "current_subtotal_price_set": {
      "shop_money": {
        "amount": "224.97",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "224.97",
        "currency_code": "INR"
      }
    },
    "current_total_additional_fees_set": null,
    "current_total_discounts": "0.00",
    "current_total_discounts_set": {
      "shop_money": {
        "amount": "0.00",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "0.00",
        "currency_code": "INR"
      }
    },
    "current_total_duties_set": null,
    "current_total_price": "238.47",
    "current_total_price_set": {
      "shop_money": {
        "amount": "238.47",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "238.47",
        "currency_code": "INR"
      }
    },
    "current_total_tax": "13.50",
    "current_total_tax_set": {
      "shop_money": {
        "amount": "13.50",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "13.50",
        "currency_code": "INR"
      }
    },
    "customer_locale": null,
    "device_id": null,
    "discount_codes": [],
    "email": "",
    "estimated_taxes": false,
    "financial_status": "paid",
    "fulfillment_status": null,
    "landing_site": null,
    "landing_site_ref": null,
    "location_id": null,
    "merchant_of_record_app_id": null,
    "name": "#1006SHOPIFYSUFF_",
    "note": "this is testing order created by API",
    "note_attributes": [],
    "number": 6,
    "order_number": 1006,
    "order_status_url": "https://d04a8f-92.myshopify.com/71621378306/orders/00d3694cedc48b5bc04d2f3a315adcd3/authenticate?key=b298e1e930f0a9837352ae9cca01c519",
    "original_total_additional_fees_set": null,
    "original_total_duties_set": null,
    "payment_gateway_names": [
      ""
    ],
    "phone": null,
    "po_number": null,
    "presentment_currency": "INR",
    "processed_at": "2024-09-19T23:57:06+05:30",
    "reference": null,
    "referring_site": null,
    "source_identifier": null,
    "source_name": "161501970433",
    "source_url": null,
    "subtotal_price": "224.97",
    "subtotal_price_set": {
      "shop_money": {
        "amount": "224.97",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "224.97",
        "currency_code": "INR"
      }
    },
    "tags": "",
    "tax_exempt": false,
    "tax_lines": [
      {
        "price": "13.50",
        "rate": 0.06,
        "title": "State tax",
        "price_set": {
          "shop_money": {
            "amount": "13.50",
            "currency_code": "INR"
          },
          "presentment_money": {
            "amount": "13.50",
            "currency_code": "INR"
          }
        },
        "channel_liable": false
      }
    ],
    "taxes_included": false,
    "test": false,
    "token": "00d3694cedc48b5bc04d2f3a315adcd3",
    "total_discounts": "0.00",
    "total_discounts_set": {
      "shop_money": {
        "amount": "0.00",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "0.00",
        "currency_code": "INR"
      }
    },
    "total_line_items_price": "224.97",
    "total_line_items_price_set": {
      "shop_money": {
        "amount": "224.97",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "224.97",
        "currency_code": "INR"
      }
    },
    "total_outstanding": "0.00",
    "total_price": "238.47",
    "total_price_set": {
      "shop_money": {
        "amount": "238.47",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "238.47",
        "currency_code": "INR"
      }
    },
    "total_shipping_price_set": {
      "shop_money": {
        "amount": "0.00",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "0.00",
        "currency_code": "INR"
      }
    },
    "total_tax": "13.50",
    "total_tax_set": {
      "shop_money": {
        "amount": "13.50",
        "currency_code": "INR"
      },
      "presentment_money": {
        "amount": "13.50",
        "currency_code": "INR"
      }
    },
    "total_tip_received": "0.00",
    "total_weight": 0,
    "updated_at": "2024-09-19T23:57:07+05:30",
    "user_id": null,
    "billing_address": null,
    "customer": null,
    "discount_applications": [],
    "fulfillments": [],
    "line_items": [
      {
        "id": 14421120712962,
        "admin_graphql_api_id": "gid://shopify/LineItem/14421120712962",
        "attributed_staffs": [],
        "current_quantity": 3,
        "fulfillable_quantity": 3,
        "fulfillment_service": "manual",
        "fulfillment_status": null,
        "gift_card": false,
        "grams": 1300,
        "name": "Big Brown Bear Boots2test",
        "price": "74.99",
        "price_set": {
          "shop_money": {
            "amount": "74.99",
            "currency_code": "INR"
          },
          "presentment_money": {
            "amount": "74.99",
            "currency_code": "INR"
          }
        },
        "product_exists": false,
        "product_id": null,
        "properties": [],
        "quantity": 3,
        "requires_shipping": true,
        "sku": null,
        "taxable": true,
        "title": "Big Brown Bear Boots2test",
        "total_discount": "0.00",
        "total_discount_set": {
          "shop_money": {
            "amount": "0.00",
            "currency_code": "INR"
          },
          "presentment_money": {
            "amount": "0.00",
            "currency_code": "INR"
          }
        },
        "variant_id": null,
        "variant_inventory_management": null,
        "variant_title": null,
        "vendor": null,
        "tax_lines": [
          {
            "channel_liable": false,
            "price": "13.50",
            "price_set": {
              "shop_money": {
                "amount": "13.50",
                "currency_code": "INR"
              },
              "presentment_money": {
                "amount": "13.50",
                "currency_code": "INR"
              }
            },
            "rate": 0.06,
            "title": "State tax"
          }
        ],
        "duties": [],
        "discount_allocations": []
      }
    ],
    "payment_terms": null,
    "refunds": [],
    "shipping_address": null,
    "shipping_lines": []
  };
  
  
  const destinationJson = {
    "topic": "yoc-order-capture",
    "key": {
      "orgId": "UKSMT",
      "sellingChannel": "CEVA-HOST",
      "orderId": "SHOPIFY-"+sourceJson.id
    },
    "value": {
      "orgId": "UKSMT",
      "sellingChannel": "CEVA-HOST",
      "orderId": "SHOPIFY-"+sourceJson.id,
      "orderDate": "2024-09-10T16:40:03Z",
      "orderType": "SalesOrder",
      "customerId": 1337,
      "partialFillAllowed": false,
      "sellerOrgId": "SITMERCH01",
      "customFields": {
        "incoTerm": "DAP",
        "marketplaceShopRef": "FFshop1"
      },
      "addressInfo": [
        {
          "type": "shipping_address",
          "contact": {
            "email": "",
            "phone": null
          },
          "address": {
            "addressLine1": "(Updated by Alex) LIEU DIT LE BOURG",
            "addressLine2": "",
            "city": "VIPLAIX",
            "country": "FR",
            "zipCode": "03370"
          }
        },
        {
          "type": "billing_address",
          "contact": {
            "email": "",
            "phone": null
          },
          "address": {
            "addressLine1": null,
            "addressLine2": ""
          }
        }
      ],
      "orderLines": [
        {
          "orderLineId": 5958602653954,
          "orderLineType": "SHIP",
          "fulfillmentType": "SHIP",
          "fulfillmentService": "STD-HOME",
          "partialFillAllowed": false,
          "productId": "S1-P1",
          "productDescription": "Camera",
          "productType": "DEFAULT",
          "uom": "EACH",
          "carrierServiceCode": "NA-Test",
          "scac": "FR-CP",
          "customFields": {
            "marketplaceLineRef": "FFLineRef1",
            "signatureRequiredFlag": true
          },
          "prices": [
            {
              "value": 20,
              "name": "UnitPriceHT",
              "useForTotals": false
            },
            {
              "value": 20,
              "name": "UnitPriceTTC",
              "useForTotals": true
            },
            {
              "value": 20,
              "name": "UnitPriceTTCWithShipping",
              "useForTotals": false
            }
          ],
          "addressInfo": [
            {
              "type": "shipTo",
              "contact": {
                "firstName": "XYZ",
                "lastName": "XYZ",
                "email": "XYZ",
                "phone": "XYZ"
              },
              "address": {
                "addressLine1": "NA",
                "addressLine2": "NA",
                "city": "Delhi",
                "country": "IN",
                "zipCode": "343442"
              },
              "isActive": true
            }
          ],
          "dates": {
            "estimatedShipDate": {
              "max": "2024-04-03T10:40:03Z"
            },
            "estimatedDeliveryDate": {
              "max": "2024-04-04T10:40:03Z"
            }
          },
          "valueAddedServices": [
            {
              "type": "Delivery_Note",
              "details": {
                "instructions": "{fnac_order[order_delivery_note]}",
                "message": "{message}",
                "image": "{image}"
              }
            },
            {
              "type": "Product_to_take_back",
              "details": {
                "instructions": "{fnac_order_details[nb_products_to_take_back]}",
                "message": "{message}",
                "image": "{image}"
              }
            }
          ]
        }
      ],
      "orderTotals": {
        "totalAmount": "238.47"
      }
    },
    "operation": "create",
    "isFullyQualifiedTopicName": false
  }


// Convert the JSON object to a string
const jsonContent = JSON.stringify(destinationJson, null, 2);

// Define the file name where the JSON will be written
const fileName = 'output.json';

// Write the JSON content to a file
fs.writeFile(fileName, jsonContent, 'utf8', (err) => {
  if (err) {
    console.error("An error occurred while writing the JSON to file:", err);
    return;
  }
  console.log(`JSON file has been saved as ${fileName}`);
});